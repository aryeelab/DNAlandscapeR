## ----sessionInfo, results='asis', echo=FALSE-----------------------------
toLatex(sessionInfo())

