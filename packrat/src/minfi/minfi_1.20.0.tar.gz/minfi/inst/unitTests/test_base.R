test_base <- function() {
    checkTrue(TRUE)
}

