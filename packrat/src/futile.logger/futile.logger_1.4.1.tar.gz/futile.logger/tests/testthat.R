library(testthat)
test_check("futile.logger")