require("bumphunter") || stop("unable to load bumphunter")
BiocGenerics:::testPackage("bumphunter")
