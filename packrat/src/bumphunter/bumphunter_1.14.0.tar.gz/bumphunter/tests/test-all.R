library('testthat')
test_check('bumphunter')
