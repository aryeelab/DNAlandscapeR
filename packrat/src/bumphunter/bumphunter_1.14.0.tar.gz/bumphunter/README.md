This is the developer version of the [bumphunter](http://bioconductor.org/packages/devel/bioc/html/bumphunter.html) R/Bioconductor package.

[Bioconductor build/check report](http://master.bioconductor.org/checkResults/devel/bioc-LATEST/bumphunter/)

