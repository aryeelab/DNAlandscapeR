setGeneric("bumphunter", function(object, ...) {
    standardGeneric("bumphunter")
})
