require("GenomicFeatures") || stop("unable to load GenomicFeatures package")
GenomicFeatures:::.test()
