BiocGenerics:::testPackage('Rsamtools')
