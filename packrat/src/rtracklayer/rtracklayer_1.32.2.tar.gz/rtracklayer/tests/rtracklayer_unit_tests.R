require("rtracklayer") || stop("unable to load rtracklayer package")
rtracklayer:::.test()
