library(testthat)
library(diffloop)

test_check("diffloop")
