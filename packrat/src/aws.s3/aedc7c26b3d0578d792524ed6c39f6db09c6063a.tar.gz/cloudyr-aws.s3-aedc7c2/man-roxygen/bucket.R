#' @param bucket Character string with the name of the bucket, or an object of class \dQuote{s3_bucket}.
