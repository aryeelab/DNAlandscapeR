### =========================================================================
### The getSeq() generic
### -------------------------------------------------------------------------


setGeneric("getSeq", function(x, ...) standardGeneric("getSeq"))

### Methods are defined in BSgenome and Rsamtools.

