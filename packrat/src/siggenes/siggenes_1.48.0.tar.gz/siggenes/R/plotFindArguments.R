plotFindArguments<-function(onlyTab=FALSE,logit=TRUE,pos.legend=NULL,legend.cex=0.8,col=NULL,
		main=NULL,xlab=NULL,ylab=NULL,only.a0=FALSE,lty=1,lwd=1,y.intersp=1.1){
	list(onlyTab=onlyTab,logit=logit,pos.legend=pos.legend,legend.cex=legend.cex,col=col,
		main=main,xlab=xlab,ylab=ylab,only.a0=only.a0,lty=lty,lwd=lwd,
		y.intersp=y.intersp)
}

