library(testthat)
library(sparseHiC)

test_check("sparseHiC")
