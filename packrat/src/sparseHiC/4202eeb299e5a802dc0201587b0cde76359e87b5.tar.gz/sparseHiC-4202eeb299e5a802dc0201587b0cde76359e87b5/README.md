# sparseHiC
R package for the efficient compression of HiC data
